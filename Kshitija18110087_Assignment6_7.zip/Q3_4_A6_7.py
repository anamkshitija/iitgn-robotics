#Kshitija Anam 18110087

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from sympy import *

# Arm 1
l1 = 0.25
r1 = l1/2
R1 = 0.365
m1 = 1
J1 = (1 / 3) * m1 * (l1**2)
stack1 = []

# Arm 2
l2 = 0.25
r2 = l2/2
R2 = 0.365
m2 = 1
J2 = (1 / 3) * m2 * (l2**2)
stack2 = []

# Arm 3
l3 = 0.25
r3 = l3/2
R3 = 0.365
m3 = 1
J3 = (1 / 3) * m3 * (l3**2)
stack3 = []

g = 9.81

t=symbols('t')
t_0 = 0
t_f = 10
div=100
T = np.linspace(t_0,t_f,div)

A = np.array([0.4,0.06,0.1])
B = np.array([0.4,0.01,0.1])

def ikscara(x, y, z, d1, d2, d3):
    # using formulae from the textbook
    r = abs((x ** 2 + y ** 2 - d1**2 - d2 ** 2) / (2 * d1 * d2))
    theta2 = np.arctan(np.sqrt(abs(1 - r ** 2)) / r)
    theta1 = np.arctan(y / x) - np.arctan(
        (d2 * np.sin(theta2)) / (d1 + d2 * np.cos(theta2)))
    d = d3 - z
    return theta1, theta2, d

def fkscara(theta1,theta2,d3,l1,l2,l3):
    theta1 = theta1*np.pi/180
    theta2 = theta2*np.pi/180
    dx = l1*np.cos(theta1) + l2*np.cos(theta2+theta1)
    dy = l2*np.sin(theta1) + l2*np.sin(theta2+theta1)
    dz = l1-d3
    return dx,dy,dz


#a
def time_der(y,T,l1,l2,l3,m1,m2,m3,Kp,Kd):
    global stack1, stack2, stack3
    # States of the system 
    q1, q1d, q2, q2d, q3, q3d = y
    t = T

    q1des= 0.0158763096506925*(t**3) - 0.238144644760388*(t**2) - 8.81312226013872e-17*t - 27.4757704901373
    q1ddes= 0.0476289289520776*(t**2) - 0.476289289520776*t - 8.81312226013872e-17
    q2des= -0.00335794159825115*(t**3) + 0.0503691239737671*(t**2) + 1.86403203886252e-17*t + 72.0130722001709
    q2ddes= -0.0100738247947534*(t**2) + 0.100738247947534*t + 1.86403203886252e-17
    q3des= 0.150000000000000
    q3ddes= 0
  
    # Computing error
    u1= Kp*(q1des-q1)+Kd*(q1ddes-q1d)
    u2= Kp*(q2des-q2)+Kd*(q2ddes-q2d)
    u3= Kp*(q3des-q3)+Kd*(q3ddes-q3d)
    tau= np.array([[u1],[u2],[u3]])

    alpha = J1 + ((r1**2) * m1) + ((l1**2) * m2) + ((l1**2) * m3)
    beta = J2 + J3 + ((l2**2) * m3) + ((r2**2) * m2)
    gamma = l1 * l2 * m3 + l1 * r2 * m2


    D = np.array([[alpha + beta + 2*gamma*np.cos(q2), beta + 2*gamma*np.cos(q2), 0],
                [beta + 2*gamma*np.cos(q2), beta, 0],
                [0, 0, m3]])

    C = np.array([[-gamma*np.sin(q2)*q2d, -gamma*np.sin(q2)*(q2d + q1d), 0],
                    [gamma*np.sin(q2)*q1d, 0, 0],
                    [0, 0, 0]])
    
    Qdot= np.array([[q1d],[q2d],[q3d]])
    CQdot = np.matmul(C,Qdot)

    G = (np.array([[0], [0], [m3*g]]))

    qd = np.matmul(np.linalg.inv(D),(tau-CQdot-G)) 
    q1dd = qd[0]
    q2dd = qd[1]
    q3dd = qd[2]
    stack1 = np.hstack((stack1,q1))
    stack2 = np.hstack((stack2,q2))
    stack3 = np.hstack((stack3,q3))
    return q1d, q1dd, q2d, q2dd, q3d, q3dd

# Defining Initial condition
[q1_0,q2_0,q3_0]= ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
ini_cond = np.array([q1_0,0,q2_0,0,q3_0,0]) 

#Solving dynamic equation
output1 = odeint(time_der, ini_cond, T, args=(l1,l2,l3,m1,m2,m3,2,5000))

plt.plot(output1[:,0])
plt.grid()
plt.show()

plt.plot(output1[:,2])
plt.grid()
plt.show()

plt.plot(output1[:,4])
plt.grid()
plt.show()

#b
def FF_control(y,T,l1,l2,l3,m1,m2,m3,Kp,Kd):
    # Actuator Parameters
    Jm1 = 0.4e-4 
    Jm2 = 0.4e-4
    Jm3 = 0.4e-4
    Bm1 = 4.77e-05
    Bm2 = 4.77e-05
    Bm3 = 4.77e-05
    Kb1 = 0.0232
    Kb2 = 0.0232
    Kb3 = 0.0232
    Km1 = 2.32e-02
    Km2 = 2.32e-02
    Km3 = 2.32e-02
    r1 = 1/100
    r2 = 1/100
    r3 = 1/100

    global stack1, stack2, stack3
    # States of the system 
    q1, q1d, q2, q2d, q3, q3d = y
    t = T

    q1des= 0.0158763096506925*(t**3) - 0.238144644760388*(t**2) - 8.81312226013872e-17*t - 27.4757704901373
    q1ddes= 0.0476289289520776*(t**2) - 0.476289289520776*t - 8.81312226013872e-17
    q2des= -0.00335794159825115*(t**3) + 0.0503691239737671*(t**2) + 1.86403203886252e-17*t + 72.0130722001709
    q2ddes= -0.0100738247947534*(t**2) + 0.100738247947534*t + 1.86403203886252e-17
    q3des= 0.150000000000000
    q3ddes= 0

    alpha = J1 + ((r1**2) * m1) + ((l1**2) * m2) + ((l1**2) * m3)
    beta = J2 + J3 + ((l2**2) * m3) + ((r2**2) * m2)
    gamma = l1 * l2 * m3 + l1 * r2 * m2

    D = np.array([[alpha + beta + 2*gamma*np.cos(q2), beta + 2*gamma*np.cos(q2), 0],
                [beta + 2*gamma*np.cos(q2), beta, 0],
                [0, 0, m3]])

    C = np.array([[-gamma*np.sin(q2)*q2d, -gamma*np.sin(q2)*(q2d + q1d), 0],
                    [gamma*np.sin(q2)*q1d, 0, 0],
                    [0, 0, 0]])
    Qdot= np.array([[q1d],[q2d],[q3d]])
    CQdot = np.matmul(C,Qdot)

    G = (np.array([[0], [0], [m3*g]]))

    # Array for desired q
    Qdes = np.array([[q1des],[q2des],[q3des]])
    Qddes = np.array([[q1ddes],[q2ddes],[q3ddes]])

    # Array for real q
    Q = np.array([[q1],[q2],[q3]])
    Qd = np.array([[q1d],[q2d],[q3d]])

    #Actuator Dynamics
    Jeff = np.array([[Jm1/r1**2,0,0],[0,Jm2/r2**2,0],[0,0,Jm3/r3**2]])
    Beff = np.array([[(Bm1+Kb1*Km1/R1)/r1**2,0,0],[0,(Bm2+Kb2*Km2/R2)/r2**2,0],[0,0,(Bm3+Kb3*Km3/R3)/r3**2]])
    Bqd = np.matmul(Beff,Qd)
    #Control
    K = np.array([[Km1/(r1*R1),0,0],[0,Km2/(r2*R2),0],[0,0,Km3/(r3*R3)]])

    u1= Kp*(q1des-q1)+Kd*(q1ddes-q1d)+((Jm1/r1**2)/(Km1/(r1*R1)))*q1ddes+((Bm1+Kb1*Km1/R1)/r1**2)*q1des
    u2= Kp*(q2des-q2)+Kd*(q2ddes-q2d)+((Jm2/r2**2)/(Km2/(r2*R2)))*q2ddes+((Bm2+Kb2*Km2/R2)/r2**2)*q2des
    u3= Kp*(q3des-q3)+Kd*(q3ddes-q3d)+((Jm3/r3**2)/(Km3/(r3*R3)))*q3ddes+((Bm3+Kb3*Km3/R3)/r3**2)*q3des
    tau= np.array([[u1],[u2],[u3]])

    qd = np.matmul(np.linalg.inv(D),(tau-CQdot-G)) 
    q1dd = qd[0]
    q2dd = qd[1]
    q3dd = qd[2]
    return q1d, q1dd, q2d, q2dd, q3d, q3dd

#Initial condition
[q1_0,q2_0,q3_0]= ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
ini_cond = np.array([q1_0,0,q2_0,0,q3_0,0]) 

#Solving dynamic equation
output2 = odeint(FF_control, ini_cond, T, args=(l1,l2,l3,m1,m2,m3,1000,12000))

plt.plot(output2[:,0])
plt.grid()
plt.show()

plt.plot(output2[:,2])
plt.grid()
plt.show()

plt.plot(output2[:,4])
plt.grid()
plt.show()

#c
def Comp_torque(y,T,l1,l2,l3,m1,m2,m3,Kp,Kd):
    # Actuator Parameters
    Jm1 = 0.4e-4 
    Jm2 = 0.4e-4
    Jm3 = 0.4e-4
    Bm1 = 4.77e-05
    Bm2 = 4.77e-05
    Bm3 = 4.77e-05
    Kb1 = 0.0232
    Kb2 = 0.0232
    Kb3 = 0.0232
    Km1 = 2.32e-02
    Km2 = 2.32e-02
    Km3 = 2.32e-02
    r1 = 1/100
    r2 = 1/100
    r3 = 1/100
    

    global stack1, stack2, stack3
    # States of the system 
    q1, q1d, q2, q2d, q3, q3d = y
    t = T

    q1des= 0.0158763096506925*(t**3) - 0.238144644760388*(t**2) - 8.81312226013872e-17*t - 27.4757704901373
    q1ddes= 0.0476289289520776*(t**2) - 0.476289289520776*t - 8.81312226013872e-17
    q2des= -0.00335794159825115*(t**3) + 0.0503691239737671*(t**2) + 1.86403203886252e-17*t + 72.0130722001709
    q2ddes= -0.0100738247947534*(t**2) + 0.100738247947534*t + 1.86403203886252e-17
    q3des= 0.150000000000000
    q3ddes= 0

    alpha = J1 + ((r1**2) * m1) + ((l1**2) * m2) + ((l1**2) * m3)
    beta = J2 + J3 + ((l2**2) * m3) + ((r2**2) * m2)
    gamma = l1 * l2 * m3 + l1 * r2 * m2

    D = np.array([[alpha + beta + 2*gamma*np.cos(q2), beta + 2*gamma*np.cos(q2), 0],
                [beta + 2*gamma*np.cos(q2), beta, 0],
                [0, 0, m3]])

    C = np.array([[-gamma*np.sin(q2)*q2d, -gamma*np.sin(q2)*(q2d + q1d), 0],
                    [gamma*np.sin(q2)*q1d, 0, 0],
                    [0, 0, 0]])
    Qdot= np.array([[q1d],[q2d],[q3d]])
    CQdot = np.matmul(C,Qdot)

    G = (np.array([[0], [0], [m3*g]]))

    # Array for desired q
    Qdes = np.array([[q1des],[q2des],[q3des]])
    Qddes = np.array([[q1ddes],[q2ddes],[q3ddes]])

    # Array for real q
    Q = np.array([[q1],[q2],[q3]])
    Qd = np.array([[q1d],[q2d],[q3d]])

    #Actuator Dynamics
    Jeff = np.array([[Jm1/r1**2,0,0],[0,Jm2/r2**2,0],[0,0,Jm3/r3**2]])
    Beff = np.array([[(Bm1+Kb1*Km1/R1)/r1**2,0,0],[0,(Bm2+Kb2*Km2/R2)/r2**2,0],[0,0,(Bm3+Kb3*Km3/R3)/r3**2]])
    Bqd = np.matmul(Beff,Qd)
    #Control
    M = D+Jeff
    h = CQdot+Bqd 
    v = Qddes+Kp*(Qdes-Q)+Kd*(Qddes-Qd)
    tau = np.matmul(M,v) + h

    qd = np.matmul(np.linalg.inv(D),(tau-CQdot-G)) 
    q1dd = qd[0]
    q2dd = qd[1]
    q3dd = qd[2]
    return q1d, q1dd, q2d, q2dd, q3d, q3dd

#Initial condition
[q1_0,q2_0,q3_0]= ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
ini_cond = np.array([q1_0,0,q2_0,0,q3_0,0]) 

#Solving dynamic equation
output3 = odeint(Comp_torque, ini_cond, T, args=(l1,l2,l3,m1,m2,m3,1000,12000))

plt.plot(output3[:,0])
plt.grid()
plt.show()

plt.plot(output3[:,2])
plt.grid()
plt.show()

plt.plot(output3[:,4])
plt.grid()
plt.show()

#d
def Multi_control(y,T,l1,l2,l3,m1,m2,m3,Kp,Kd):
    # Actuator Parameters
    Jm1 = 0.4e-4 
    Jm2 = 0.4e-4
    Jm3 = 0.4e-4
    Bm1 = 4.77e-05
    Bm2 = 4.77e-05
    Bm3 = 4.77e-05
    Kb1 = 0.0232
    Kb2 = 0.0232
    Kb3 = 0.0232
    Km1 = 2.32e-02
    Km2 = 2.32e-02
    Km3 = 2.32e-02
    r1 = 1/100
    r2 = 1/100
    r3 = 1/100

    global stack1, stack2, stack3
    # States of the system 
    q1, q1d, q2, q2d, q3, q3d = y
    t = T

    q1des= 0.0158763096506925*(t**3) - 0.238144644760388*(t**2) - 8.81312226013872e-17*t - 27.4757704901373
    q1ddes= 0.0476289289520776*(t**2) - 0.476289289520776*t - 8.81312226013872e-17
    q2des= -0.00335794159825115*(t**3) + 0.0503691239737671*(t**2) + 1.86403203886252e-17*t + 72.0130722001709
    q2ddes= -0.0100738247947534*(t**2) + 0.100738247947534*t + 1.86403203886252e-17
    q3des= 0.150000000000000
    q3ddes= 0
  
    # Computing error
    u1= Kp*(q1des-q1)+Kd*(q1ddes-q1d)
    u2= Kp*(q2des-q2)+Kd*(q2ddes-q2d)
    u3= Kp*(q3des-q3)+Kd*(q3ddes-q3d)
    tau= np.array([[u1],[u2],[u3]])

    alpha = J1 + ((r1**2) * m1) + ((l1**2) * m2) + ((l1**2) * m3)
    beta = J2 + J3 + ((l2**2) * m3) + ((r2**2) * m2)
    gamma = l1 * l2 * m3 + l1 * r2 * m2


    D = np.array([[alpha + beta + 2*gamma*np.cos(q2), beta + 2*gamma*np.cos(q2), 0],
                [beta + 2*gamma*np.cos(q2), beta, 0],
                [0, 0, m3]])

    C = np.array([[-gamma*np.sin(q2)*q2d, -gamma*np.sin(q2)*(q2d + q1d), 0],
                    [gamma*np.sin(q2)*q1d, 0, 0],
                    [0, 0, 0]])
    
    Qdot= np.array([[q1d],[q2d],[q3d]])
    CQdot = np.matmul(C,Qdot)

    G = (np.array([[0], [0], [m3*g]]))

    # Array for desired q
    Qdes = np.array([[q1des],[q2des],[q3des]])
    Qddes = np.array([[q1ddes],[q2ddes],[q3ddes]])

    # Array for real q
    Q = np.array([[q1],[q2],[q3]])
    Qd = np.array([[q1d],[q2d],[q3d]])

    #Actuator Dynamics
    J = np.array([[Jm1/r1**2,0,0],[0,Jm2/r2**2,0],[0,0,Jm3/r3**2]])
    B = np.array([[(Bm1+Kb1*Km1/R1)/r1**2,0,0],[0,(Bm2+Kb2*Km2/R2)/r2**2,0],[0,0,(Bm3+Kb3*Km3/R3)/r3**2]])
    Bqd = np.matmul(B,Qd)
    #Control
    K = np.array([[Km1/(r1*R1),0,0],[0,Km2/(r2*R2),0],[0,0,Km3/(r3*R3)]])
    Vk = Kp*(Qdes-Q)+Kd*(Qddes-Qd)
    tau = np.matmul(K,Vk)

    qd = np.matmul(np.linalg.inv(D),(tau-CQdot-G)) 
    q1dd = qd[0]
    q2dd = qd[1]
    q3dd = qd[2]
    return q1d, q1dd, q2d, q2dd, q3d, q3dd

# Defining Initial condition
[q1_0,q2_0,q3_0]= ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
ini_cond = np.array([q1_0,0,q2_0,0,q3_0,0]) 

#Solving dynamic equation
output4 = odeint(Multi_control, ini_cond, T, args=(l1,l2,l3,m1,m2,m3,2,5000))

plt.plot(output4[:,0])
plt.grid()
plt.show()

plt.plot(output4[:,2])
plt.grid()
plt.show()

plt.plot(output4[:,4])
plt.grid()
plt.show()

X1 = np.copy(T)
X2 = np.copy(T)
X3 = np.copy(T)
X4 = np.copy(T)
Y1 = np.copy(T)
Y2 = np.copy(T)
Y3 = np.copy(T)
Y4 = np.copy(T)
Z1 = np.copy(T)
Z2 = np.copy(T)
Z3 = np.copy(T)
Z4 = np.copy(T)
Xd = np.copy(T)
Yd = np.copy(T)
Zd = np.copy(T)

for i in range(len(T)):
    QQ1 = np.array([output1[i,0],output1[i,2],output1[i,4]])
    QQ2 = np.array([output2[i,0],output2[i,2],output2[i,4]])
    QQ3 = np.array([output3[i,0],output3[i,2],output3[i,4]])
    QQ4 = np.array([output4[i,0],output4[i,2],output4[i,4]])
    [X1[i],Y1[i],Z1[i]]= fkscara(QQ1[0],QQ1[1],QQ1[2],0.25,0.25,0.25)  
    [X2[i],Y2[i],Z2[i]]= fkscara(QQ2[0],QQ2[1],QQ2[2],0.25,0.25,0.25)  
    [X3[i],Y3[i],Z3[i]]= fkscara(QQ3[0],QQ3[1],QQ3[2],0.25,0.25,0.25)  
    [X4[i],Y4[i],Z4[i]]= fkscara(QQ4[0],QQ4[1],QQ4[2],0.25,0.25,0.25) 

plt.plot(T,output1[:,0])
plt.plot(T,output2[:,0])
plt.plot(T,output3[:,0])
plt.plot(T,output4[:,0])
plt.xlabel('Time')
plt.legend(["Q1_PD compensator","Q1_Feedforward control","Q1_COmputed Torque","Q1_Multivariable Control"])
plt.grid()
plt.show()

plt.plot(T,output1[:,2])
plt.plot(T,output2[:,2])
plt.plot(T,output3[:,2])
plt.plot(T,output4[:,2])
plt.xlabel('Time')
plt.legend(["Q2_PD compensator","Q2_Feedforward control","Q2_Computed Torque","Q2_Multivariable Control"])
plt.grid()
plt.show()

plt.plot(T,output1[:,4])
plt.plot(T,output2[:,4])
plt.plot(T,output3[:,4])
plt.plot(T,output4[:,4])
plt.xlabel('Time')
plt.legend(["Q3_PD compensator","Q3_Feedforward control","Q3_COmputed Torque","Q3_Multivariable Control"])
plt.grid()
plt.show()

##4 with error
output1 = odeint(time_der, ini_cond, T, args=(l1*0.8,l2,l3,m1,m2,m3,2,5000))
output2 = odeint(FF_control, ini_cond, T, args=(l1*0.8,l2,l3,m1,m2,m3,2,5000))
output3 = odeint(Comp_torque, ini_cond, T, args=(l1*0.8,l2,l3,m1,m2,m3,2,5000))
output4 = odeint(Multi_control, ini_cond, T, args=(l1*0.8,l2,l3,m1,m2,m3,2,5000))

plt.plot(T,output1[:,0])
plt.plot(T,output2[:,0])
plt.plot(T,output3[:,0])
plt.plot(T,output4[:,0])
plt.xlabel('Time')
plt.title("With 20% error in length 1")
plt.legend(["Q1_PD compensator","Q1_Feedforward control","Q1_COmputed Torque","Q1_Multivariable Control"])
plt.grid()
plt.show()

plt.plot(T,output1[:,2])
plt.plot(T,output2[:,2])
plt.plot(T,output3[:,2])
plt.plot(T,output4[:,2])
plt.xlabel('Time')
plt.title("With 20% error in length 1")
plt.legend(["Q2_PD compensator","Q2_Feedforward control","Q2_Computed Torque","Q2_Multivariable Control"])
plt.grid()
plt.show()

plt.plot(T,output1[:,4])
plt.plot(T,output2[:,4])
plt.plot(T,output3[:,4])
plt.plot(T,output4[:,4])
plt.xlabel('Time')
plt.title("With 20% error in length 1")
plt.legend(["Q3_PD compensator","Q3_Feedforward control","Q3_COmputed Torque","Q3_Multivariable Control"])
plt.grid()
plt.show()
