#Kshitija Anam 18110087

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from sympy import *

A = np.array([0.4,0.06,0.1])
B = np.array([0.4,0.01,0.1])

t=symbols('t')
t_0 = 0
t_f = 10
div=100
T = np.linspace(t_0,t_f,div)

def ikscara(x, y, z, d1, d2, d3):
    # using formulae from the textbook
    r = abs((x ** 2 + y ** 2 - d1**2 - d2 ** 2) / (2 * d1 * d2))
    theta2 = np.arctan(np.sqrt(abs(1 - r ** 2)) / r)
    theta1 = np.arctan(y / x) - np.arctan(
        (d2 * np.sin(theta2)) / (d1 + d2 * np.cos(theta2)))
    d = d3 - z
    return theta1, theta2, d

#Joint 1 - Trajectory Planning
def Trajec_J1(t_0,t_f):
  [theta1_i,theta2_i,d3_i] = ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
  [theta1_f,theta2_f,d3_f] = ikscara(B[0],B[1],B[2],0.25,0.25,0.25)
  Y_0 = np.array([[theta1_i],[0],[theta1_f],[0]])
  Y_B = np.array([[1,t_0,t_0**2,t_0**3],
                  [0,1,2*t_0,3*t_0**2],
                  [1,t_f,t_f**2,t_f**3],
                  [0,1,2*t_f,3*t_f**2]])
  Y_B_inv = np.linalg.inv(Y_B)
  Y_A = Y_B_inv@Y_0
  a_0 = Y_A[0,0]
  a_1 = Y_A[1,0]
  a_2 = Y_A[2,0]
  a_3 = Y_A[3,0]
  q1 = a_0+(a_1*t)+(a_2*(t**2))+(a_3*(t**3))
  q1d = a_1+(2*a_2*t)+(3*a_3*(t**2))
  q1dd = 2*a_2+(6*a_3*t)
  return [q1,q1d,q1dd]

#Joint 2 - Trajectory Planning
def Trajec_J2(t_0,t_f):
  [theta1_i,theta2_i,d3_i] = ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
  [theta1_f,theta2_f,d3_f] = ikscara(B[0],B[1],B[2],0.25,0.25,0.25)
  Y_0 = np.array([[theta2_i],[0],[theta2_f],[0]])
  Y_B = np.array([[1,t_0,t_0**2,t_0**3],
                  [0,1,2*t_0,3*t_0**2],
                  [1,t_f,t_f**2,t_f**3],
                  [0,1,2*t_f,3*t_f**2]])
  Y_B_inv = np.linalg.inv(Y_B)
  Y_A = Y_B_inv@Y_0
  a_0 = Y_A[0,0]
  a_1 = Y_A[1,0]
  a_2 = Y_A[2,0]
  a_3 = Y_A[3,0]
  q2 = a_0+(a_1*t)+(a_2*(t**2))+(a_3*(t**3))
  q2d = a_1+(2*a_2*t)+(3*a_3*(t**2))
  q2dd = 2*a_2+(6*a_3*t)
  return [q2,q2d,q2dd]

#Joint 3 - Trajectory Planning
def Trajec_J3(t_0,t_f):
  [theta1_i,theta2_i,d3_i] = ikscara(A[0],A[1],A[2],0.25,0.25,0.25)
  [theta1_f,theta2_f,d3_f] = ikscara(B[0],B[1],B[2],0.25,0.25,0.25)
  Y_0 = np.array([[d3_i],[0],[d3_f],[0]])
  Y_B = np.array([[1,t_0,t_0**2,t_0**3],
                  [0,1,2*t_0,3*t_0**2],
                  [1,t_f,t_f**2,t_f**3],
                  [0,1,2*t_f,3*t_f**2]])
  Y_B_inv = np.linalg.inv(Y_B)
  Y_A = Y_B_inv@Y_0
  a_0 = Y_A[0,0]
  a_1 = Y_A[1,0]
  a_2 = Y_A[2,0]
  a_3 = Y_A[3,0]
  q3 = a_0+(a_1*t)+(a_2*(t**2))+(a_3*(t**3))
  q3d = a_1+(2*a_2*t)+(3*a_3*(t**2))
  q3dd = 2*a_2+(6*a_3*t)
  return [q3,q3d,q3dd]

[q1,q1d,q1dd] = Trajec_J1(t_0,t_f)
[q2,q2d,q2dd] = Trajec_J2(t_0,t_f)
[q3,q3d,q3dd] = Trajec_J3(t_0,t_f)

Q1 = np.copy(T)
Q2 = np.copy(T)
Q3 = np.copy(T)

for i in range(len(T)):
  Q1[i] = q1.subs(t,T[i])
  Q2[i] = q2.subs(t,T[i])
  Q3[i] = q3.subs(t,T[i])

plt.plot(T,Q1)
plt.title("Joint1")
plt.grid()
plt.show()

plt.plot(T,Q2)
plt.title("Joint2")
plt.grid()
plt.show()

plt.plot(T,Q3)
plt.title("Joint3")
plt.grid()
plt.show()

# for next task
print(q1)
print(q1d)
print(q2)
print(q2d)
print(q3)
print(q3d)