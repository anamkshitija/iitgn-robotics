#Kshitija Anam 18110087

#Secret Word: DEV

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from sympy import *

t=symbols('t')
#Trajectory Planning
def Trajec(y_0,yd_0,y_f,yd_f,t_0,t_f):
  Y_0 = np.array([[y_0],[yd_0],[y_f],[yd_f]])
  Y_B = np.array([[1,t_0,t_0**2,t_0**3],
                  [0,1,2*t_0,3*t_0**2],
                  [1,t_f,t_f**2,t_f**3],
                  [0,1,2*t_f,3*t_f**2]])
  Y_B_inv = np.linalg.inv(Y_B)
  Y_A = Y_B_inv@Y_0
  a_0 = Y_A[0,0]
  a_1 = Y_A[1,0]
  a_2 = Y_A[2,0]
  a_3 = Y_A[3,0]
  y = a_0+(a_1*t)+(a_2*(t**2))+(a_3*(t**3))
  yd = a_1+(2*a_2*t)+(3*a_3*(t**2))
  ydd = 2*a_2+(6*a_3*t)
  return [y,yd,ydd]

t_0 = 0
t_f = 10
div=100
T = np.linspace(t_0,t_f,div)

[y,yd,ydd] = Trajec(0.06,0,0.01,0,t_0,t_f)

Y=np.copy(T)
Yd=np.copy(T)
Ydd=np.copy(T)

for i in range(len(T)):
  Y[i] = y.subs(t,T[i])
  Yd[i] = yd.subs(t,T[i])
  Ydd[i] = ydd.subs(t,T[i])


plt.plot(T,Y)
plt.title(["Position"])
plt.grid()
plt.show()

plt.plot(T,Yd)
plt.title(["Velocity"])
plt.grid()
plt.show()

plt.plot(T,Ydd)
plt.title(["Acceleration"])
plt.grid()
plt.show()
